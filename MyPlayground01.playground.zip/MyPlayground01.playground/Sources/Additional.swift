import Foundation

public let globalConstant = 100;
//This is comment
public func publicFunction() {
    print("Hello")
}
