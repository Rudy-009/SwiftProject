import UIKit

var str = "Hello, playground"
print(str)

var j = 0;

for i in 0...3 {
    j+=i
}
